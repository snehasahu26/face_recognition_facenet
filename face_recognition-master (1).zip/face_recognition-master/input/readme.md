
This is the path to put your classifier image before alignment.The structure may like this:

* input
  * class1(for face recognition it's a person's name)
    * image1 (for face recognition it's a person's photo)
    * image2
    * ...
  * class2
    * image1
    * image2
    * ...
  * class...
