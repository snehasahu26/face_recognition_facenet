
This is the path to put your own classifier like **.pkl
