
This is path to put your models checkpoints and pb whatever.
